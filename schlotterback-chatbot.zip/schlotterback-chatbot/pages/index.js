import ChatBox from '../components/ChatBox'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 to-fuchsia-200">
      <ChatBox />
    </div>
  )
}